import pandas as pd

df = pd.read_csv('benchmarking_data.csv')

print(df.to_string()) 