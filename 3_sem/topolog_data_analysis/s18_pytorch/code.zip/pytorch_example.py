# install pip3 install torch torchvision
import torch

x = torch.rand(5, 3)
print(x)